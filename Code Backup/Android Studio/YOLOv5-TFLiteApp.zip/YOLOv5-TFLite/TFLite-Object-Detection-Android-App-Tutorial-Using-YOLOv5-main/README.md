# TFLite-Object-Detection-Android-App-Tutorial-Using-YOLOv5

To understand the code, Please check this video: https://youtu.be/ROn1_O2zEtk

Steps Performed:

1- Train yolov5 model

2- Convert yolov5 (.pt model) into a tensorflow model(.pb file)

3- Convert tensorflow model (.pb model) to tflite model.

4- Download and install Android Studio

5- Build and run your Object detection App.


