# initial-dataset
Number of Classes: 33
Number of Images: 1229
